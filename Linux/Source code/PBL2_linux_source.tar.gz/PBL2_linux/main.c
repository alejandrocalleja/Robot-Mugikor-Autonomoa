#define _CRT_SECURE_NO_WARNINGS

#include <SDL2/SDL.h>
#include <SDL2/SDL_main.h>
#include <SDL2/SDL_image.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "header/defineak.h"
#include "header/graphics.h"
#include "header/image.h"
#include "header/events.h"
#include "header/orokorrak.h"
#include "header/algoritmoak.h"
#include "header/programa.h"


int main(int argc, char* argv[]) {

	ROBOTA robot;
	int jarraitu = 0, kargatuta = 0, buelta = 1;
	MAPAK* ptrMapaLehena = NULL, *auxBorratu = NULL; 
	STOCK_PRODUKTO* stockDeCadaProducto = NULL;
	HELBIDEAK *helbideak = NULL;

	
	//Programa hasieratzeko funtzioak
    programaHasieratu();
	mapakHasieratu(&ptrMapaLehena);
	kargaPantaila();

	//Hasierako posizioak
	robot.hasieraFuera = INICIO_ROBOT_SALA;
	robot.hasieraBarruan = 0;
	

	jarraitu = enpresenPantaila(); //Enpresak

	if (jarraitu == 1) { //Mapa Arasur bada
		hasieratuHelbideak(&helbideak, jarraitu); //Arasur enpresarentzat beharrezkoak diren helbideak
		do {
			jarraitu = produktuenPantaila(&robot); //Arasur enpresaren produktuak
			if (jarraitu == 1) {
				stockHasieratu(&stockDeCadaProducto, "fitx/stock1.txt"); //Stocka fitxategitik hartu
				jarraitu = koloreenPantaila(&robot, stockDeCadaProducto); //Arasur enpresaren produktu berdinaren koloreak

				if (jarraitu == 1) {
					lehioaItxi();
					programaHasieratu();

					if (kargatuta == 0) {//Lehenengo buelta bada, mapak fitxategitik hartzen ditu eta ibilbide sinplea egiten du
						mapakHasieratuFitx(&ptrMapaLehena, "fitx/mapaArasur.txt", 0);
						mapakHasieratuFitx(&ptrMapaLehena, "fitx/mapaDentro.txt", 0);
						kargatuta = 1;

						robotaWarshall(&robot, &ptrMapaLehena, 1, *helbideak);
						robotaEstrella(&robot, &ptrMapaLehena, 2, *helbideak);
					}
					else {//Lehenengo buelta bada, bakarrik bigarren mapa berriro hartzen du
						mapakHasieratuFitx(&ptrMapaLehena, "fitx/mapaDentro.txt", 2);

						if (robot.hasieraFuera == robot.amaieraFuera) {//Biltegi egokian badago, bakarrik biltegian mugitu
							robotaEstrella(&robot, &ptrMapaLehena, 2, *helbideak);
						}
						else {//Beste biltegian badago, biltegi egokira mugitu
							Hiru_mugimendu(&robot, &ptrMapaLehena, helbideak);
						}

						if (buelta == 2) {//produktua biltegitik kendu badu, hasierako puntura eraman
							bueltakoBidea(&robot, &ptrMapaLehena, helbideak);
							buelta = 0;
						}		
					}	
					buelta++;
				}
			}
			jarraitu = jarraituPantaila();//jarraitu nahi baduzu
		} while (jarraitu == 1);
		if (kargatuta == 1) {
			zerrendaOsoaLiberatu_Stock(&stockDeCadaProducto);
			auxBorratu = ptrMapaLehena;
			while (ptrMapaLehena != NULL) {
				ptrMapaLehena = ptrMapaLehena->ptrHurrengoa;
				zerrendaOsoaLiberatu_Puntos(&auxBorratu->puntos);
				zerrendaOsoaLiberatu_Mapak(&auxBorratu);
				auxBorratu = ptrMapaLehena;
			}
		}
	}

	
	else if (jarraitu == 2) {
		hasieratuHelbideak(&helbideak, jarraitu);//Mercedes enpresarentzat beharrezkoak diren helbideak
		lehioaItxi();
		programaHasieratu();
		do {
			destinoaHasieratu(&robot);//puntu bat aukeratu	

			if (kargatuta == 0) {//Lehenengo buelta bada, mapak fitxategitik hartzen ditu
				mapakHasieratuFitx(&ptrMapaLehena, "fitx/mapaMercedes.txt", 0);
				kargatuta = 1;
				//grafoa_kalkulatu(&ptrMapaLehena->grafoDeCostos, ptrMapaLehena->puntos, ptrMapaLehena->tamainaMapa);
				//mapaGorde(ptrMapaLehena->grafoDeCostos, "Mercedes.txt");
			}
			else {//Bigarren buelta bada, aurreko mapa berridazten du
				mapakHasieratuFitx(&ptrMapaLehena, "fitx/mapaMercedes.txt", 1);
			}

			robotaEstrella(&robot, &ptrMapaLehena, 1, *helbideak);

			jarraitu = jarraituPantaila();//jarraitu nahi baduzu
			if (jarraitu == 1) {
				jarraitu = 2;
			}
			else if (jarraitu ==2) {
				jarraitu = 1;
			}
		} while (jarraitu == 2);
		if (kargatuta == 1) {
			auxBorratu = ptrMapaLehena;
			while (ptrMapaLehena != NULL) {
				ptrMapaLehena = ptrMapaLehena->ptrHurrengoa;
				zerrendaOsoaLiberatu_Puntos(&auxBorratu->puntos);
				zerrendaOsoaLiberatu_Mapak(&auxBorratu);
				auxBorratu = ptrMapaLehena;
			}
		}
	}
	

	//stockGorde(stockDeCadaProducto, "stock1.txt");
	

    programaAmaitu();
    return 0;
}
