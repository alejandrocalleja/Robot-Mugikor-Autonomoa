#define _CRT_SECURE_NO_WARNINGS

#include <SDL2/SDL.h>
#include <SDL2/SDL_main.h>
#include <SDL2/SDL_image.h>

#include <stdio.h>
#include <stdlib.h>

#include "header/graphics.h"
#include "header/image.h"

pIMG pHead = NULL;
int imgKop = 0;
int id = 0;

int imgKargatu(char* fileName) {
    pIMG pAux = NULL;
    pAux = (pIMG)malloc(sizeof(IMG));
    pAux->pNext = NULL;
    SDL_Surface* surface;
    SDL_Renderer* renderer = getRenderer();           //Lehioa sortu eta gero renderizatu behar dugu argazkiak jartzeko 

    if (imgKop < MAX_IMG) {
        surface = SDL_LoadBMP(fileName);        //Surface sortu (CPU)
        if (surface == NULL) {
            printf("Unable to load image %s! SDL_image Error: %s\n", fileName, IMG_GetError());
            return -1;
        }
        pAux->texture = SDL_CreateTextureFromSurface(renderer, surface);          //Textura sortu aurreko surface-eko pixel-etik
        if (pAux->texture == NULL) {
            printf("Unable to create texture from %s! SDL Error: %s\n", fileName, SDL_GetError());
            return -1;
        }
        pAux->dest.x = pAux->dest.y = 0;
        pAux->dest.w = surface->w;
        pAux->dest.h = surface->h;
        SDL_FreeSurface(surface);               //Kargatutako surface-a liberatu
        pAux->id = id;
        imgKop++;
        id++;
        imgListarenBukaeranSartu(&pHead, pAux);
    }
    else {
        printf("ERROR: Exceeded the maximum number of images, couldn't load %s image\n", fileName);
        return -1;
    }
    return id - 1;
}
int imgMugitu(int id, int x, int y) {
    int pos = 0, ret = 0;
    SDL_Renderer* renderer = getRenderer();
    SDL_Rect aux;
    pIMG img;
    img = imgBilatu(id);

    if (img == NULL) {
        printf("ERROR: Couldn't fine the %d image\n", id);
        return -1;
    }
    else {
        img->dest.x = x;
        img->dest.y = y;
    }
    SDL_RenderClear(renderer);
    imgsMarraztu();
    return ret;
}
void imgsMarraztu(void) {
    int i = 0, aux = 0, bl = 0;
    pIMG ptr = NULL;
    ptr = pHead;
    do {
        aux = imgMarraztu(ptr->texture, &ptr->dest);
        ptr = ptr->pNext;
        i++;
        if (aux == -1) {
            printf("ERROR: Couldn't print all textures\n");
            bl = -1;
        }
    } while (ptr != NULL && i < imgKop && bl == 0);
    SDL_RenderPresent(getRenderer());
}
pIMG imgBilatu(int id) {
    pIMG aux = NULL;
    char str[128];
    int aurkituta = 0, pos = 1;

    aux = pHead;

    if (pHead == NULL) {
        printf("ERROR: Couldn't find the image. No images finded.\n");
    }
    else {
        if (pHead->pNext == NULL) {
            if (pHead->id == id) {
                //printf("INFO: %d image finded, %d pos...\n", id, pos);                        ESTO ES UNA MIERDA
                aurkituta = 1;
            }
            else printf("ERROR: Couldn't find the image\n");
        }
        else {
            while (aux != NULL && aurkituta == 0) {
                if (aux->id == id) {
                    //printf("INFO: %d image finded, %d pos...\n", id, pos);                    ESTO ES UNA MIERDA
                    aurkituta = 1;
                }
                else {
                    pos++;
                    aux = aux->pNext;
                }
            }
            if (aurkituta != 1) printf("ERROR: Couldn't find the image\n");
        }
    }
    return aux;
}
void imgListarenBukaeranSartu(pIMG* ppHead, pIMG pSrc) {
    pIMG aux = NULL;

    aux = *ppHead;

    if (*ppHead == NULL) {
        *ppHead = pSrc;
        pSrc->pNext = NULL;
    }
    else {
        while (aux->pNext != NULL) {
            aux = aux->pNext;
        }

        aux->pNext = pSrc;
        pSrc->pNext = NULL;
    }
}
void imgKendu(int id) {
    int aurkituta = 0;
    pIMG aux = NULL;
    pIMG prev = NULL;
    SDL_Renderer* renderer = getRenderer();

    aux = pHead->pNext;
    prev = pHead;

    if (prev == NULL) printf("ERROR: Couldn't find any image\n");
    else {
        if (prev->id == id) {
            SDL_DestroyTexture(prev->texture);
            pHead = pHead->pNext;
            free(prev);
            imgKop--;
            SDL_RenderClear(renderer);
            if(imgKop > 0) imgsMarraztu();
            SDL_RenderPresent(renderer);
            
        }
        else {
            while (aux != NULL && aurkituta == 0) {
                if (aux->id == id) {
                    aurkituta = 1;
                    printf("INFO: %d image finded, deleting...\n", id);
                }
                else {
                    aux = aux->pNext;
                    prev = prev->pNext;
                }

            }
            if (aurkituta == 1) {
                SDL_DestroyTexture(aux->texture);
                prev->pNext = aux->pNext;
                free(aux);
                imgKop--;
                SDL_RenderClear(renderer);
                if (imgKop > 0) imgsMarraztu();
                SDL_RenderPresent(renderer);
            }
            else printf("ERROR: Couldn't find the image\n");
        }

    }
}
