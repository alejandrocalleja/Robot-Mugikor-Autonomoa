#define _CRT_SECURE_NO_WARNINGS

#include <SDL2/SDL.h>
#include <SDL2/SDL_main.h>
#include <SDL2/SDL_image.h>

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

#include "header/events.h"
#include "header/orokorrak.h"
#include "header/defineak.h"

#include "header/algoritmoak.h"
#include "header/graphics.h"
#include "header/image.h"

#include "header/programa.h"


//Floyd warshall erabiltzeko mapa hautatu, helbideak sartu, irudiak sortu, fitategitik koordenatuen informazioa hartu eta gorde, eta kalkuluak egin
void robotaWarshall(ROBOTA* robot, MAPAK** ptrMapaLehena, int mapPos, HELBIDEAK helbideak) {
	MAPAK* aux = NULL;
	HELBIDEAK auxhelb;
	OBJ pantaila, destino;

	aux = mapaHartu(*ptrMapaLehena, mapPos);
	auxhelb = helbideaHartu(helbideak, mapPos);


	pantaila.id = imgKargatu(auxhelb.imgMapa);
	destino.id = imgKargatu(auxhelb.imgDestino);
	robot->img.id = imgKargatu(auxhelb.imgRobot);


	if (aux->eginda == EZ) {//bide motzena kalkulatuta ez badago
		puntuaHasieratu(&aux->puntos, auxhelb.txtPuntos);
	}

	robotarenPosizioa(&robot, aux->puntos, 0);

	//amaierako puntua non dagoen irudikatzeko
	destino.pos = bueltatuPosizioa(aux->puntos, (aux->tamainaMapa - robot->amaieraFuera - 1));
	imgMugitu(destino.id, destino.pos.x, destino.pos.y);

	//floyd warshall-en bitartez ibilbidea kalkulatu eta egin
	ibilbideaWarshall(*robot, &aux, aux->tamainaMapa);
	robot->hasieraFuera = robot->amaieraFuera;//amaierara ailegatzerakoan, hasierako posizioa hori bihurtu
	puntuaGorde(aux->puntos, auxhelb.txtPuntos);

	imgKendu(robot->img.id);
	imgKendu(pantaila.id);
	imgKendu(destino.id);
}
//A izarra erabiltzeko mapa hautatu, helbideak sartu, irudiak sortu, fitategitik koordenatuen informazioa hartu eta gorde, eta kalkuluak egin
void robotaEstrella(ROBOTA* robot, MAPAK** ptrMapaLehena, int mapPos, HELBIDEAK helbideak) {
	MAPAK* aux = NULL;
	HELBIDEAK auxhelb;
	OBJ pantaila, destino;

	aux = mapaHartu(*ptrMapaLehena, mapPos);
	auxhelb = helbideaHartu(helbideak, mapPos);
	puntuaHasieratu(&aux->puntos, auxhelb.txtPuntos);


	pantaila.id = imgKargatu(auxhelb.imgMapa);
	destino.id = imgKargatu(auxhelb.imgDestino);
	robot->img.id = imgKargatu(auxhelb.imgRobot);

	robotarenPosizioa(&robot, aux->puntos, 1);

	//amaierako puntua non dagoen irudikatzeko
	destino.pos = bueltatuPosizioa(aux->puntos, (aux->tamainaMapa - robot->puntuaBarruan - 1));
	imgMugitu(destino.id, destino.pos.x, destino.pos.y);
	imgMugitu(robot->img.id, robot->img.pos.x, robot->img.pos.y);

	if (robot->hasieraBarruan != robot->puntuaBarruan) {// puntuan jada ez badago 
		//A izarraren bitartez ibilbidea kalkulatu eta egin
		ibilbideaEstrella(*robot, &aux, aux->tamainaMapa);
		robot->hasieraBarruan = robot->puntuaBarruan;//amaierara ailegatzerakoan, hasierako posizioa hori bihurtu
		puntuaGorde(aux->puntos, auxhelb.txtPuntos);

	}

	if (robot->amaieraFuera == robot->hasieraFuera) SDL_Delay(1500); //ibilbide guztia bukatu badu

	imgKendu(robot->img.id);
	imgKendu(pantaila.id);
	imgKendu(destino.id);
}
//A izarraren bitartez ibilbidea kalkulatu, jarraitu behar den bidea sortu eta bide honen amaierara ailegatu arte robota mugitu
void ibilbideaEstrella(ROBOTA robot, MAPAK** mapak, int tamainaMapa) {

	CAMINOS* ibilbidea = NULL;
	ALMACENES_POS* puntos;

	puntos = (*mapak)->puntos; //koordenatuak auxiliar batean sartu

	imgMugitu(robot.img.id, robot.img.pos.x, robot.img.pos.y);
	imgsMarraztu();

	(*mapak)->grafoDeCaminos = heuristika_kalkulatu(puntos, tamainaMapa);//distantzia errealen datuak mapen struct-ean sartu

	ibilbidea = A_estrella(*mapak, robot.hasieraBarruan, robot.puntuaBarruan, tamainaMapa);

	do {
		if (ibilbidea->ptrHurrengoa != NULL) {
			robot.img.pos = ibilbideaEgin(puntos, ibilbidea->ptrHurrengoa->numero - 1, ibilbidea->numero - 1, robot.img);
			ibilbidea = ibilbidea->ptrHurrengoa;
		}
		/*ebentu = ebentuaJasoGertatuBada();
		if (ebentu == GERTAERA_IRTEN) {
			atera = -1;
		}*/

	} while (ibilbidea->ptrHurrengoa != NULL); //amaierako puntura ailegatu arte mugitu
}

//Floyd warshall-en bitartez ibilbidea kalkulatu, jarraitu behar den bidea sortu eta bide honen amaierara ailegatu arte robota mugitu
void ibilbideaWarshall(ROBOTA robot, MAPAK** mapak, int tamainaMapa) {

	CAMINOS* ibilbidea = NULL;
	ALMACENES_POS* puntos;

	puntos = (*mapak)->puntos; //koordenatuak auxiliar batean sartu

	imgMugitu(robot.img.id, robot.img.pos.x, robot.img.pos.y);
	imgsMarraztu();

	if ((*mapak)->eginda == EZ) {//kalkulua oraindik eginda ez badago
		floydWarshall(*mapak, tamainaMapa);
	}
	caminoMasCorto(**mapak, &ibilbidea, robot); //ibilbidea hartu


	do {
		robot.img.pos = ibilbideaEgin(puntos, ibilbidea->ptrHurrengoa->numero, ibilbidea->numero, robot.img);
		ibilbidea = ibilbidea->ptrHurrengoa;
		/*ebentu = ebentuaJasoGertatuBada();
		if (ebentu == GERTAERA_IRTEN) {
			atera = -1;
		}*/

	} while (ibilbidea->ptrHurrengoa != NULL);//amaierako puntura ailegatu arte mugitu


}
//puntu bat ausaz aukeratzen du
void destinoaHasieratu(ROBOTA* robot) {
	int kop = 7, dest = 0;
	int zki;
	srand(time(NULL));

	for (int i = 0; i < 3; i++) {
		zki = rand() % kop + 1;
	}
	

	switch (zki) {
	case 1:
		dest = 4;
		break;
	case 2:
		dest = 7;
		break;
	case 3:
		dest = 9;
		break;
	case 4:
		dest = 11;
		break;
	case 5:
		dest = 21;
		break;
	case 6:
		dest = 37;
		break;
	case 7:
		dest = 50;
		break;
	}

	robot->hasieraFuera = INICIO_ROBOT_SALA;
	robot->amaieraFuera = INICIO_ROBOT_SALA;
	robot->puntuaBarruan = dest;
}
//robotaren hasierako puntua izanda, bere hasierako koordenatuetan ezartzeko
void robotarenPosizioa(ROBOTA** robot, ALMACENES_POS* puntuak, int non) {
	ALMACENES_POS* aux = puntuak;

	if (non == 0) {
		while ((*robot)->hasieraFuera != aux->punto) {
			aux = aux->ptrHurrengoa;
		}
	}
	else {
		while ((*robot)->hasieraBarruan != aux->punto) {
			aux = aux->ptrHurrengoa;
		}
	}

	(*robot)->img.pos = aux->pos;
}

//Misko-ren hasieratze pantaila sortzen du
void kargaPantaila(void) {
	OBJ pantaila;
	pantaila.id = imgKargatu(SARRERA_PANTAILA);
	imgsMarraztu();
	SDL_Delay(2000);
	imgKendu(pantaila.id);
}
//Ze enpresaren barruan klikatu duen ikusten du, eta horren arabera zenbaki bat bueltatzen du
int enpresenPantaila() {

	OBJ fondo, enpresa, lista;
	POSIZIOA sagua;
	int ebentu = 0, atera = 0;

	//Irudiak sortu eta posizioan mugitu
	fondo.id = imgKargatu(FONDO);
	enpresa.id = imgKargatu(ENPRESAK);
	lista.id = imgKargatu(ENPRESAK_LISTA);
	imgsMarraztu();
	imgMugitu(enpresa.id, 170, 200);
	imgMugitu(lista.id, 195, 310);

	do {

		ebentu = ebentuaJasoGertatuBada();

		if (ebentu == LEFT_CLICK) {
			//Click egiterakoan saguaren posizioa hartu eta non klikatu duen ikusten du
			sagua = saguarenPosizioa();
			atera = nonKlickEginHasiera(sagua);
		}
		else if (ebentu == GERTAERA_IRTEN) {
			atera = -1;
		}
	} while (atera == 0);

	imgKendu(fondo.id);
	imgKendu(enpresa.id);
	imgKendu(lista.id);

	return atera;
}
//Ze produktuaren barruan klikatu duen ikusten du, eta horren arabera zenbaki bat bueltatzen du eta kanpoko amaierako posizioa ezartzen du
int produktuenPantaila(ROBOTA* robot) {

	OBJ fondo, produktuak, lista;
	POSIZIOA sagua;
	int ebentu = 0, atera = 0, click = 0;

	//Irudiak sortu eta posizioan mugitu
	fondo.id = imgKargatu(FONDO);
	produktuak.id = imgKargatu(PRODUKTUAK);
	lista.id = imgKargatu(PRODUKTUAK_LISTA);
	imgsMarraztu();
	imgMugitu(produktuak.id, 170, 200);
	imgMugitu(lista.id, 185, 325);

	do {

		ebentu = ebentuaJasoGertatuBada();
		click = 0;
		if (ebentu == LEFT_CLICK) {
			//Click egiterakoan saguaren posizioa hartu eta non klikatu duen ikusten du
			sagua = saguarenPosizioa();
			click = nonKlickEginProduktua(sagua);
		}
		if (click > 0) {
			//Produkturen batean klikatu badu amaierako posizioa esarri
			atera = 1;
			robot->amaieraFuera = zerProduktuKlikatu(click);
		}
		else if (ebentu == GERTAERA_IRTEN) {
			atera = -1;
		}
	} while (atera == 0);

	imgKendu(fondo.id);
	imgKendu(produktuak.id);
	imgKendu(lista.id);

	return atera;
}
//Ze kolorearen barruan klikatu duen ikusten du, eta horren arabera zenbaki bat bueltatzen du eta barruko amaierako posizioa ezartzen du
int koloreenPantaila(ROBOTA* robot, STOCK_PRODUKTO* stockDeCadaProducto) {

	OBJ fondo, motak, lista;
	POSIZIOA sagua;
	int ebentu = 0, atera = 0, click = 0;

	//Irudiak sortu eta posizioan mugitu
	fondo.id = imgKargatu(FONDO);
	motak.id = imgKargatu(MOTAK);
	lista.id = imgKargatu(MOTAK_LISTA);
	imgsMarraztu();
	imgMugitu(motak.id, 170, 200);
	imgMugitu(lista.id, 165, 295);

	do {

		ebentu = ebentuaJasoGertatuBada();
		click = 0;
		if (ebentu == LEFT_CLICK) {
			//Click egiterakoan saguaren posizioa hartu eta non klikatu duen ikusten du
			sagua = saguarenPosizioa();
			click = nonKlickEginKolorea(sagua);
		}
		if (click > 0) {
			//Kolore batean klikatu badu amaierako kolorea esarri
			atera = 1;
			robot->produktuarenKolorea = zerKoloreKlikatu(click);

			kolorearekinAukeratuPuntua(stockDeCadaProducto, robot);

		}
		else if (ebentu == GERTAERA_IRTEN) {
			atera = -1;
		}
	} while (atera == 0);

	imgKendu(fondo.id);
	imgKendu(motak.id);
	imgKendu(lista.id);

	return atera;
}
//Stockaren arabera, kolorea ikusita barruko posizioa ezartzen du
void kolorearekinAukeratuPuntua(STOCK_PRODUKTO* stockDeCadaProducto, ROBOTA* robot) {

	STOCK_PRODUKTO* aux = NULL;
	STOCK_COLOR* auxColor = NULL;

	aux = bilatuProduktua(stockDeCadaProducto, *robot);

	switch (robot->produktuarenKolorea)
	{
	case ROJO:
		auxColor = bilatuColorea(aux->colores, *robot);
		if (auxColor->stockAbajo == SIN_ESPACIO) {
			robot->puntuaBarruan = 3;
		}
		else {
			robot->puntuaBarruan = 2;
		}
		break;
	case VERDE:
		auxColor = bilatuColorea(aux->colores, *robot);
		if (auxColor->stockAbajo == SIN_ESPACIO) {
			robot->puntuaBarruan = 7;
		}
		else {
			robot->puntuaBarruan = 6;
		}
		break;
	case AZUL:
		auxColor = bilatuColorea(aux->colores, *robot);
		if (auxColor->stockAbajo == SIN_ESPACIO) {
			robot->puntuaBarruan = 6;
		}
		else {
			robot->puntuaBarruan = 5;
		}
		break;
	case ROJO_NARANJA:
		auxColor = bilatuColorea(aux->colores, *robot);
		if (auxColor->stockAbajo == SIN_ESPACIO) {
			robot->puntuaBarruan = 5;
		}
		else {
			robot->puntuaBarruan = 4;
		}
		break;
	case AMBAR:
		auxColor = bilatuColorea(aux->colores, *robot);
		if (auxColor->stockAbajo == SIN_ESPACIO) {
			robot->puntuaBarruan = 1;
		}
		else {
			robot->puntuaBarruan = 0;
		}
		break;
	case AMARILLO:
		auxColor = bilatuColorea(aux->colores, *robot);
		if (auxColor->stockAbajo == SIN_ESPACIO) {
			robot->puntuaBarruan = 3;
		}
		else {
			robot->puntuaBarruan = 2;
		}
		break;
	case LIMA:
		auxColor = bilatuColorea(aux->colores, *robot);
		if (auxColor->stockAbajo == SIN_ESPACIO) {
			robot->puntuaBarruan = 11;
		}
		else {
			robot->puntuaBarruan = 10;
		}
		break;
	case VIOLETA:
		auxColor = bilatuColorea(aux->colores, *robot);
		if (auxColor->stockAbajo == SIN_ESPACIO) {
			robot->puntuaBarruan = 2;
		}
		else {
			robot->puntuaBarruan = 1;
		}
		break;
	case MAGENTA:
		auxColor = bilatuColorea(aux->colores, *robot);
		if (auxColor->stockAbajo == SIN_ESPACIO) {
			robot->puntuaBarruan = 10;
		}
		else {
			robot->puntuaBarruan = 9;
		}
		break;
	case NEGRO:
		auxColor = bilatuColorea(aux->colores, *robot);
		if (auxColor->stockAbajo == SIN_ESPACIO) {
			robot->puntuaBarruan = 1;
		}
		else {
			robot->puntuaBarruan = 0;
		}
		break;
	case BLANCO:
		auxColor = bilatuColorea(aux->colores, *robot);
		if (auxColor->stockAbajo == SIN_ESPACIO) {
			robot->puntuaBarruan = 9;
		}
		else {
			robot->puntuaBarruan = 8;
		}
		break;
	case GRIS:
		auxColor = bilatuColorea(aux->colores, *robot);
		if (auxColor->stockAbajo == SIN_ESPACIO) {
			robot->puntuaBarruan = 2;
		}
		else {
			robot->puntuaBarruan = 1;
		}
		break;
	default:
		break;
	}
}
//Ze produktu klikatu duen arabera, amaierako posizioa esarri
ALMACENES zerProduktuKlikatu(int click) {

	switch (click)
	{
	case 1:
		return RATONES;
	case 2:
		return TEKLADOS;
	case 3:
		return CASCOS;
	case 4:
		return RAM;
	case 5:
		return VENTILADOR;
	case 6:
		return SAGU_AZPIKO;
	case 7:
		return MOVILES;
	case 8:
		return MASCARILLAS;
	case 9:
		return CAMARAS;
	case 10:
		return DORREA;
	default:
		return -1;
		break;
	}
}
//Ze kolore klikatu duen arabera, amaierako kolorea esarri
COLORES zerKoloreKlikatu(int click) {

	switch (click)
	{
	case 1:
		return ROJO;
	case 2:
		return VERDE;
	case 3:
		return AZUL;
	case 4:
		return ROJO_NARANJA;
	case 5:
		return AMBAR;
	case 6:
		return AMARILLO;
	case 7:
		return LIMA;
	case 8:
		return VIOLETA;
	case 9:
		return MAGENTA;
	case 10:
		return NEGRO;
	case 11:
		return BLANCO;
	case 12:
		return GRIS;
	default:
		return -1;
		break;
	}
}

//Enpresa baten barruan klikatu duen ikusteko
int nonKlickEginHasiera(POSIZIOA sagua) {

	int click = 0;

	if (sagua.x > 205 && sagua.y > 315 && sagua.x < 360 && sagua.y < 360) {
		click = 1;
	}
	if (sagua.x > 205 && sagua.y > 385 && sagua.x < 360 && sagua.y < 430) {
		click = 2;
	}

	return click;
}
//Produktu baten barruan klikatu duen ikusteko
int nonKlickEginProduktua(POSIZIOA sagua) {

	int click = 0;

	if (sagua.x > 190 && sagua.y > 330 && sagua.x < 410 && sagua.y < 370) {
		click = 1;//sagua
	}
	else if (sagua.x > 190 && sagua.y > 403 && sagua.x < 410 && sagua.y < 443) {
		click = 2;//teklatua
	}
	else if (sagua.x > 190 && sagua.y > 475 && sagua.x < 410 && sagua.y < 515) {
		click = 3;//kaskoak
	}
	else if (sagua.x > 190 && sagua.y > 550 && sagua.x < 315 && sagua.y < 590) {
		click = 4;//RAM
	}
	else if (sagua.x > 190 && sagua.y > 615 && sagua.x < 315 && sagua.y < 655) {
		click = 5;//CPU
	}
	else if (sagua.x > 660 && sagua.y > 330 && sagua.x < 970 && sagua.y < 370) {
		click = 6;//desodorantea
	}
	else if (sagua.x > 660 && sagua.y > 403 && sagua.x < 915 && sagua.y < 443) {
		click = 7;//mugikorrak
	}
	else if (sagua.x > 660 && sagua.y > 475 && sagua.x < 880 && sagua.y < 515) {
		click = 8;//maskarak
	}
	else if (sagua.x > 660 && sagua.y > 550 && sagua.x < 870 && sagua.y < 590) {
		click = 9;//kamarak
	}
	else if (sagua.x > 660 && sagua.y > 615 && sagua.x < 870 && sagua.y < 655) {
		click = 10;//liburuak
	}


	return click;
}
//Kolore baten barruan klikatu duen ikusteko
int nonKlickEginKolorea(POSIZIOA sagua) {

	int click = 0;

	if (sagua.x > 165 && sagua.y > 285 && sagua.x < 330 && sagua.y < 325) {
		return 1;
	}
	else if (sagua.x > 165 && sagua.y > 360 && sagua.x < 335 && sagua.y < 395) {
		return 2;
	}
	else if (sagua.x > 165 && sagua.y > 435 && sagua.x < 330 && sagua.y < 470) {
		return 3;
	}
	else if (sagua.x > 165 && sagua.y > 510 && sagua.x < 470 && sagua.y < 545) {
		return 4;
	}
	else if (sagua.x > 165 && sagua.y > 585 && sagua.x < 320 && sagua.y < 620) {
		return 5;
	}
	else if (sagua.x > 165 && sagua.y > 660 && sagua.x < 300 && sagua.y < 695) {
		return 6;
	}


	else if (sagua.x > 705 && sagua.y > 285 && sagua.x < 830 && sagua.y < 325) {
		return 7;
	}
	else if (sagua.x > 705 && sagua.y > 360 && sagua.x < 865 && sagua.y < 395) {
		return 8;
	}
	else if (sagua.x > 705 && sagua.y > 435 && sagua.x < 905 && sagua.y < 470) {
		return 9;
	}
	else if (sagua.x > 705 && sagua.y > 510 && sagua.x < 855 && sagua.y < 545) {
		return 10;
	}
	else if (sagua.x > 705 && sagua.y > 585 && sagua.x < 835 && sagua.y < 620) {
		return 11;
	}
	else if (sagua.x > 705 && sagua.y > 660 && sagua.x < 835 && sagua.y < 695) {
		return 12;
	}


	return click;
}
//Galderaren barruan klikatu duen ikusteko
int nonKlickEginAmaiera(POSIZIOA sagua) {

	int click = 0;

	if (sagua.x > 374 && sagua.y > 470 && sagua.x < 430 && sagua.y < 500) {
		click = 1;//jarraitu
	}
	else if(sagua.x > 800 && sagua.y > 470 && sagua.x < 850 && sagua.y < 500){
		click = 2;//fuera
	}
	return click;
}
//pixelez pixel hurrengo puntura mugitzeko
POSIZIOA ibilbideaEgin(ALMACENES_POS* puntosAlmacenes, int hurrengoPuntua, int hasierakoPuntua, OBJ rob) {

	ALMACENES_POS* hasierakoPos = NULL, * amaierakoPos = NULL;

	int y1, y2, x1, x2;

	hasierakoPos = bilatuPuntua(hasierakoPuntua, puntosAlmacenes);
	amaierakoPos = bilatuPuntua(hurrengoPuntua, puntosAlmacenes);

	if (hasierakoPos->pos.x == amaierakoPos->pos.x) {//x koordenatuak berdinak direnean y koordenatuetan pixelez pixel mugitu
		y1 = rob.pos.y;
		y2 = amaierakoPos->pos.y;
		if (y2 > y1) {//amaiera gorago badago
			while (y1 != y2) {
				y1 = y1 + 1;
				imgMugitu(rob.id, rob.pos.x, y1);
				SDL_Delay(5);
			}
			rob.pos.y = y1;
		}
		else {//amaiera beherago badago
			while (y1 != y2) {
				y1 = y1 - 1;
				imgMugitu(rob.id, rob.pos.x, y1);
				SDL_Delay(5);
			}
			rob.pos.y = y1;
		}

	}
	if (hasierakoPos->pos.y == amaierakoPos->pos.y) {//y koordenatuak berdinak direnean x koordenatuetan pixelez pixel mugitu
		x1 = rob.pos.x;
		x2 = amaierakoPos->pos.x;
		if (x2 > x1) {//amaiera eskuinerago badago
			while (x1 != x2) {
				x1 = x1 + 1;
				imgMugitu(rob.id, x1, rob.pos.y);
				SDL_Delay(5);
			}
			rob.pos.x = x1;
		}
		else {//amaiera ezkerrerago badago
			while (x1 != x2) {
				x1 = x1 - 1;
				imgMugitu(rob.id, x1, rob.pos.y);
				SDL_Delay(5);
			}
			rob.pos.x = x1;
		}

	}

	return rob.pos;

}
//puntu baten koordenatuak bueltatzen ditu
ALMACENES_POS* bilatuPuntua(int puntua, ALMACENES_POS* puntosAlmacenes) {

	ALMACENES_POS* aux = NULL;

	aux = puntosAlmacenes;

	while (aux->punto != puntua) {
		aux = aux->ptrHurrengoa;
	}

	return aux;
}
STOCK_PRODUKTO* bilatuProduktua(STOCK_PRODUKTO* stockDeCadaProducto, ROBOTA robot) {

	STOCK_PRODUKTO* aux = NULL;

	aux = stockDeCadaProducto;

	while (aux->producto != robot.amaieraFuera) {
		aux = aux->ptrHurrengoa;
	}

	return aux;
}
STOCK_COLOR* bilatuColorea(STOCK_COLOR* stockDeCadaProducto, ROBOTA robot) {

	STOCK_COLOR* aux = NULL;

	aux = stockDeCadaProducto;

	while (aux->color != robot.produktuarenKolorea) {
		aux = aux->ptrHurrengoa;
	}

	return aux;
}
//mapen struct-aren barruan ID-aren arabera, posizio horretan dagoen informazioa bueltatzen da auxiliar batera
MAPAK* mapaHartu(MAPAK* ptrMapaLehena, int id) {
	MAPAK* aux = ptrMapaLehena;

	while (aux->id != id) {
		if (aux->ptrHurrengoa != NULL) {
			aux = aux->ptrHurrengoa;
		}
		else {

		}
	}

	return aux;
}

//Beharrezkoak diren helbideak sortzen ditu, ondoren erabiltzeko
void hasieratuHelbideak(HELBIDEAK** helbideak, int enpresa) {
	HELBIDEAK* aux;


	if (enpresa == 1) {
		aux = (HELBIDEAK*)malloc(sizeof(HELBIDEAK));

		aux->id = 1;
		strcpy(aux->imgMapa, MAP1);
		strcpy(aux->imgRobot, ROBOT);
		strcpy(aux->imgDestino, DESTINO_2);
		strcpy(aux->txtMapa, "fitx/mapaArasur.txt");
		strcpy(aux->txtPuntos, "fitx/mapaPuntosArasur.txt");
		aux->ptrHurrengoa = NULL;

		helbideakAmaieran(helbideak, aux);


		aux = (HELBIDEAK*)malloc(sizeof(HELBIDEAK));

		aux->id = 2;
		strcpy(aux->imgMapa, MAP2);
		strcpy(aux->imgRobot, ROBOT_GRANDE);
		strcpy(aux->imgDestino, DESTINO_3);
		strcpy(aux->txtMapa, "fitx/mapaDentro.txt");
		strcpy(aux->txtPuntos, "fitx/mapaPuntosDentro.txt");
		aux->ptrHurrengoa = NULL;

		helbideakAmaieran(helbideak, aux);
	}
	if (enpresa == 2) {
		aux = (HELBIDEAK*)malloc(sizeof(HELBIDEAK));

		aux->id = 1;
		strcpy(aux->imgMapa, MAP3);
		strcpy(aux->imgRobot, ROBOT);
		strcpy(aux->imgDestino, DESTINO);
		strcpy(aux->txtMapa, "fitx/mapaMercedes.txt");
		strcpy(aux->txtPuntos, "fitx/mapaPuntosMercedes.txt");
		aux->ptrHurrengoa = NULL;

		helbideakAmaieran(helbideak, aux);
	}

}
//Zerrenda kateatuaren amaieran helbideak sartzeko
void helbideakAmaieran(HELBIDEAK** lehena, HELBIDEAK* aux) {
	HELBIDEAK* aux2 = NULL;

	aux2 = *lehena;

	if (*lehena == NULL) {
		*lehena = (HELBIDEAK*)malloc(sizeof(HELBIDEAK));
		*lehena = aux;
	}
	else {
		while (aux2->ptrHurrengoa != NULL) {
			aux2 = aux2->ptrHurrengoa;
		}
		aux2->ptrHurrengoa = aux;
	}

}
//helbideen struct-aren barruan ID-aren arabera, posizio horretan dagoen informazioa bueltatzen da auxiliar batera
HELBIDEAK helbideaHartu(HELBIDEAK helbideak, int mapPos) {

	while (helbideak.id != mapPos) {
		helbideak = *helbideak.ptrHurrengoa;
	}

	return helbideak;
}

//Funtzio honetan biltegi batetik atera, biltegi egokira joan eta barruan produktu zehatzera mugitzen da
void Hiru_mugimendu(ROBOTA* robot, MAPAK** ptrMapaLehena, HELBIDEAK* helbideak) {
	ROBOTA aux;
	int auxamaiera = robot->puntuaBarruan;
	aux = *robot;

	aux.puntuaBarruan = 0;//biltegiaren hasierara joan
	robotaEstrella(&aux, ptrMapaLehena, 2, *helbideak);

	aux.puntuaBarruan = auxamaiera;//biltegiaren barruko behar zuen puntura joan

	robotaWarshall(&aux, ptrMapaLehena, 1, *helbideak);
	robotaEstrella(&aux, ptrMapaLehena, 2, *helbideak);

	*robot = aux;
}
//Funtzio honetan karga punturako lekura bueltatzen da
void bueltakoBidea(ROBOTA* robot, MAPAK** ptrMapaLehena, HELBIDEAK* helbideak) {
	ROBOTA aux;

	int auxamaiera = robot->puntuaBarruan;
	robot->amaieraFuera = 0;//karga puntura joan
	robot->puntuaBarruan = 0;//biltegiaren hasierara joan

	aux = *robot;

	robotaEstrella(&aux, ptrMapaLehena, 2, *helbideak);

	aux.puntuaBarruan = auxamaiera;

	robotaWarshall(&aux, ptrMapaLehena, 1, *helbideak);


	*robot = aux;
}

int zerrendaOsoaLiberatu_Puntos(ALMACENES_POS** lehena) {

	ALMACENES_POS* aux = NULL;
	aux = *lehena;

	if (*lehena != NULL) {

		while (*lehena != NULL) {
			//hurrengo elementuan kokatu
			*lehena = (*lehena)->ptrHurrengoa;
			free(aux);
			aux = *lehena;
		}
	}
	return 1;
}


int zerrendaOsoaLiberatu_Mapak(MAPAK** lehena) {

	MAPAK* aux = NULL;
	MAPAK_FITX_FILAS* auxColum1 = NULL;
	MAPAK_FITX_COLUMNAS* auxColum2 = NULL;

	aux = *lehena;
	/*auxColum1 = (*lehena)->grafoDeCostos3->filas;
	auxColum2 = (*lehena)->grafoDeCostos3;
	auxColum11 = (*lehena)->grafoDeCostos3->filas;
	auxColum21 = (*lehena)->grafoDeCostos3;*/

	if (*lehena != NULL) {

		if ((*lehena)->grafoDeCostos != NULL) {
			auxColum1 = (*lehena)->grafoDeCostos->filas;
			auxColum2 = (*lehena)->grafoDeCostos;

			while ((*lehena)->grafoDeCostos != NULL) {
				while ((*lehena)->grafoDeCostos->filas != NULL) {
					(*lehena)->grafoDeCostos->filas = (*lehena)->grafoDeCostos->filas->ptrHurrengoaFila;
					free(auxColum1);
					auxColum1 = (*lehena)->grafoDeCostos->filas;
				}
				(*lehena)->grafoDeCostos = (*lehena)->grafoDeCostos->ptrHurrengoaColumna;
				free(auxColum2);
				auxColum2 = (*lehena)->grafoDeCostos;
			}
		}
		if ((*lehena)->grafoDeCaminos != NULL) {
			auxColum1 = (*lehena)->grafoDeCaminos->filas;
			auxColum2 = (*lehena)->grafoDeCaminos;

			while ((*lehena)->grafoDeCaminos != NULL) {
				while ((*lehena)->grafoDeCaminos->filas != NULL) {
					(*lehena)->grafoDeCaminos->filas = (*lehena)->grafoDeCaminos->filas->ptrHurrengoaFila;
					free(auxColum1);
					auxColum1 = (*lehena)->grafoDeCaminos->filas;
				}
				(*lehena)->grafoDeCaminos = (*lehena)->grafoDeCaminos->ptrHurrengoaColumna;
				free(auxColum2);
				auxColum2 = (*lehena)->grafoDeCaminos;
			}
		}
		
		free(aux);
	}


	return 1;
}

int zerrendaOsoaLiberatu_Stock(STOCK_PRODUKTO** lehena) {

	STOCK_PRODUKTO* aux = NULL;
	STOCK_COLOR* auxColor = NULL;
	aux = *lehena;
	auxColor = (*lehena)->colores;

	if (*lehena != NULL) {

		while (*lehena != NULL) {
			while ((*lehena)->colores != NULL) {
				(*lehena)->colores = (*lehena)->colores->ptrHurrengoa;
				free(auxColor);
				auxColor = (*lehena)->colores;
			}
			//hurrengo elementuan kokatu
			*lehena = (*lehena)->ptrHurrengoa;
			free(aux);
			aux = *lehena;
		}
	}
	return 1;
}
//Bide berri bat sartu nahi duen galdetzeko
int jarraituPantaila(void) {

	int ebentu = 0, atera = 0;
	POSIZIOA sagua;
	OBJ fondo, jarraitu;

	//Irudiak sortu eta posizioan mugitu
	fondo.id = imgKargatu(FONDO);
	jarraitu.id = imgKargatu(JARRAITU);
	imgsMarraztu();
	imgMugitu(jarraitu.id, 374, 238);

	do {

		ebentu = ebentuaJasoGertatuBada();

		if (ebentu == LEFT_CLICK) {
			//Click egiterakoan saguaren posizioa hartu eta non klikatu duen ikusten du
			sagua = saguarenPosizioa();
			atera = nonKlickEginAmaiera(sagua);
		}
		else if (ebentu == GERTAERA_IRTEN) {
			atera = -1;
		}
	} while (atera == 0);

	imgKendu(fondo.id);
	imgKendu(jarraitu.id);

	return atera;
}
