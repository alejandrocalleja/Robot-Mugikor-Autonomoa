#ifndef _OROKORRAK_H
#define _OROKORRAK_H

typedef struct obj {
    int id;
    POSIZIOA pos;
}OBJ;

#endif // !_OROKORRAK_H

