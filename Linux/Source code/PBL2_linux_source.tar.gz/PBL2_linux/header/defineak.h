#define SARRERA_PANTAILA "img/init1.bmp"
#define FONDO "img/init2.bmp"
#define ENPRESAK "img/enpresa.bmp"
#define ENPRESAK_LISTA "img/enpresakLista.bmp"
#define PRODUKTUAK "img/Produktuak.bmp"
#define PRODUKTUAK_LISTA "img/produktuakLista.bmp"
#define MOTAK "img/motak.bmp"
#define MOTAK_LISTA "img/motakLista.bmp"
#define IREKITA "img/abierto.bmp"
#define ITXITA "img/cerrado.bmp"
#define MAP1 "img/map1.bmp"
#define MAP2 "img/map2.bmp"
#define MAP3 "img/map3.bmp"
#define DESTINO "img/destino1.bmp"
#define DESTINO_2 "img/destino2.bmp"
#define DESTINO_3 "img/destino3.bmp"
#define ROBOT "img/robotS.bmp"
#define ROBOT_GRANDE "img/robotG.bmp"
#define JARRAITU "img/jarraituPantaila.bmp"
#define BUELTA "img/bueltakoBidea.bmp"


#define MAX_STR 128
#define INF 99999 //Infinito balioa definitu
