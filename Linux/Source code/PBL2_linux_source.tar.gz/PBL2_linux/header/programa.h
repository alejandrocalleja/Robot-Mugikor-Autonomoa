#ifndef _PROGRAMA_H
#define _PROGRAMA_H


//Floyd warshall erabiltzeko mapa hautatu, helbideak sartu, irudiak sortu, fitategitik koordenatuen informazioa hartu eta gorde, eta kalkuluak egin
void robotaWarshall(ROBOTA *robot, MAPAK** ptrMapaLehena, int mapPos, HELBIDEAK helbideak);

//A izarra erabiltzeko mapa hautatu, helbideak sartu, irudiak sortu, fitategitik koordenatuen informazioa hartu eta gorde, eta kalkuluak egin
void robotaEstrella(ROBOTA *robot, MAPAK** ptrMapaLehena, int mapPos, HELBIDEAK helbideak);

//puntu bat ausaz aukeratzen du
void destinoaHasieratu(ROBOTA* robot);

//robotaren hasierako puntua izanda, bere hasierako koordenatuetan ezartzeko
void robotarenPosizioa(ROBOTA** robot, ALMACENES_POS* puntuak, int non);

//Misko-ren hasieratze pantaila sortzen du
void kargaPantaila(void);

//Ze enpresaren barruan klikatu duen ikusten du, eta horren arabera zenbaki bat bueltatzen du
int enpresenPantaila();

//Floyd warshall-en bitartez ibilbidea kalkulatu, jarraitu behar den bidea sortu eta bide honen amaierara ailegatu arte robota mugitu
void ibilbideaWarshall(ROBOTA robot, MAPAK** mapak, int tamainaMapa);

//Zein produktuaren barruan klikatu duen ikusten du, eta horren arabera zenbaki bat bueltatzen du eta kanpoko amaierako posizioa ezartzen du
int produktuenPantaila(ROBOTA* robot);

//Enpresa baten barruan klikatu duen ikusteko
int nonKlickEginHasiera(POSIZIOA sagua);

//Produktu baten barruan klikatu duen ikusteko
int nonKlickEginProduktua(POSIZIOA sagua);

//Ze produktu klikatu duen arabera, amaierako kolorea esarri
ALMACENES zerProduktuKlikatu(int click);

//Ze kolorearen barruan klikatu duen ikusten du, eta horren arabera zenbaki bat bueltatzen du eta barruko amaierako posizioa ezartzen du
int koloreenPantaila(ROBOTA* robot, STOCK_PRODUKTO* stockDeCadaProducto);

//Kolore baten barruan klikatu duen ikusteko
int nonKlickEginKolorea(POSIZIOA sagua);

//Ze kolore klikatu duen arabera, amaierako kolorea esarri
COLORES zerKoloreKlikatu(int click);

//Galderaren barruan klikatu duen ikusteko
int nonKlickEginAmaiera(POSIZIOA sagua);

//pixelez pixel hurrengo puntura mugitzeko
POSIZIOA ibilbideaEgin(ALMACENES_POS* puntosAlmacenes, int hurrengoPuntua, int hasierakoPuntua, OBJ rob);

//puntu baten koordenatuak bueltatzen ditu
ALMACENES_POS* bilatuPuntua(int puntua, ALMACENES_POS* puntosAlmacenes);

//A izarraren bitartez ibilbidea kalkulatu, jarraitu behar den bidea sortu eta bide honen amaierara ailegatu arte robota mugitu
void ibilbideaEstrella(ROBOTA robot, MAPAK** mapak, int tamainaMapa);

//Stockaren arabera, kolorea ikusita barruko posizioa ezartzen du
void kolorearekinAukeratuPuntua(STOCK_PRODUKTO* stockDeCadaProducto, ROBOTA* robot);


STOCK_PRODUKTO* bilatuProduktua(STOCK_PRODUKTO* stockDeCadaProducto, ROBOTA robot);


STOCK_COLOR* bilatuColorea(STOCK_COLOR* stockDeCadaProducto, ROBOTA robot);

//mapen struct-aren barruan ID-aren arabera, posizio horretan dagoen informazioa bueltatzen da auxiliar batera
MAPAK* mapaHartu(MAPAK* ptrMapaLehena, int id);

//Beharrezkoak diren helbideak sortzen ditu, ondoren erabiltzeko
void hasieratuHelbideak(HELBIDEAK** helbideak, int enpresa);

//Zerrenda kateatuaren amaieran helbideak sartzeko
void helbideakAmaieran(HELBIDEAK** lehena, HELBIDEAK* aux);

//helbideen struct-aren barruan ID-aren arabera, posizio horretan dagoen informazioa bueltatzen da auxiliar batera
HELBIDEAK helbideaHartu(HELBIDEAK helbideak, int mapPos);

//Funtzio honetan biltegi batetik atera, biltegi egokira joan eta barruan produktu zehatzera mugitzen da
void Hiru_mugimendu(ROBOTA* robot, MAPAK** ptrMapaLehena, HELBIDEAK* helbideak);

//Funtzio honetan karga punturako lekura bueltatzen da
void bueltakoBidea(ROBOTA* robot, MAPAK** ptrMapaLehena, HELBIDEAK* helbideak);



int zerrendaOsoaLiberatu_Puntos(ALMACENES_POS** lehena);


int zerrendaOsoaLiberatu_Stock(STOCK_PRODUKTO** lehena);


int zerrendaOsoaLiberatu_Mapak(MAPAK** lehena);

//Bide berri bat sartu nahi duen galdetzeko
int jarraituPantaila(void);

#endif // !_OROKORRAK_H
