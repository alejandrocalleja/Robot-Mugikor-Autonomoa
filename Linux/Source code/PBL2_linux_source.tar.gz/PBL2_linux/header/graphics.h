#ifndef _GRAPHICS_H
#define _GRAPHICS_H

SDL_Renderer* getRenderer(void);

//Pantailaren tamaina hartzen du eta lehioa sortzen du
int programaHasieratu(void);
void programaAmaitu();
SDL_DisplayMode pantailarenTamainaAtera();
int imgMarraztu(SDL_Texture* texture, SDL_Rect* pDest);
//Sortutako lehioa ixten du
void lehioaItxi(void);
#endif // !_GRAPHICS_H

