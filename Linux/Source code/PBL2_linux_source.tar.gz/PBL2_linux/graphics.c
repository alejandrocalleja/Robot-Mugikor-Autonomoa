#define _CRT_SECURE_NO_WARNINGS

#include <SDL2/SDL.h>
#include <SDL2/SDL_main.h>
#include <SDL2/SDL_image.h>

#include <stdio.h>
#include <stdlib.h>

#include "header/graphics.h"

SDL_Window* window = NULL;                    // Lehioaren erakuslea sortu
SDL_Renderer* renderer;                      // GRafikoen erakuslea sortu  

SDL_Renderer* getRenderer(void) { return renderer; }

int programaHasieratu(void) {
    int i = 0, aux = 0, ret = 0;
    SDL_DisplayMode current;

    
    //SDL_Surface* gScreenSurface;            // Image data. Argazki baten pixelen datuak.

    if (SDL_Init(SDL_INIT_VIDEO) < 0) {
        printf("SDL could not initialize! SDL_Error: %s\n", SDL_GetError());
        return -1;
    }

	current.w = 1240;
	current.h = 720;
    // Sortu lehio bat hurrengo ezaugarriekin:
    window = SDL_CreateWindow(
        "Misko S.L",                  // titulua
        SDL_WINDOWPOS_UNDEFINED,           // hasierako x posizioa
        SDL_WINDOWPOS_UNDEFINED,           // hasierako y posizioa
        current.w,                               // zabalera, pixeletan
        current.h,                               // altuera
        SDL_WINDOW_OPENGL                  // flags
    );

    // Konprobatu lehioa ondo sortuta dagoela
    if (window == NULL) {
        // Lehioa ondo sortzen ez bada
        printf("Could not create window: %s\n", SDL_GetError());
        return -1;
    }

    //SDL_SetWindowFullscreen(window, SDL_WINDOW_FULLSCREEN_DESKTOP);
    SDL_SetWindowDisplayMode(window, &current);
    renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
    if (renderer == NULL) {
        printf("Renderer could not be created! SDL Error: %s\n", SDL_GetError());
        return -1;
    }
    return ret;
}

void lehioaItxi(void) {
	SDL_DestroyWindow(window);
}
void programaAmaitu() {

    // Itxi lehioa
	lehioaItxi();

    // Garbitu
    SDL_Quit();

}
SDL_DisplayMode pantailarenTamainaAtera() {
    SDL_DisplayMode aux;
    int tmp = 0;
	int should_be_zero;
    aux.driverdata = 0;

    for (int i = 0; i < SDL_GetNumVideoDisplays(); i++) {

        should_be_zero = SDL_GetCurrentDisplayMode(i, &aux);

        if (should_be_zero != 0) {
            SDL_Log("Could not get display mode for video display #%d: %s", i, SDL_GetError());
        }

        else {
            SDL_Log("Display #%d: current display mode is %dx%dpx @ %dhz.", i, aux.w, aux.h, aux.refresh_rate);
        }
    }
    return aux;
}
int imgMarraztu(SDL_Texture* texture, SDL_Rect* pDest) {
    SDL_Rect aux;
    int ret = 0;

    aux.x = aux.y = 0;
    aux.w = pDest->w;
    aux.h = pDest->h;
    ret = SDL_RenderCopy(renderer, texture, &aux, pDest);
    
    return ret;
}
