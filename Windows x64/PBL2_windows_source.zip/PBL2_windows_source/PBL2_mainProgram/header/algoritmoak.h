#ifndef _ALGORITMOAK_H
#define _ALGORITMOAK_H

typedef enum {INICIO_ROBOT_SALA, RATONES, TEKLADOS, CASCOS, RAM, VENTILADOR, SAGU_AZPIKO, MOVILES, MASCARILLAS, CAMARAS, DORREA}ALMACENES;
typedef enum { ROJO, VERDE, AZUL, ROJO_NARANJA, AMBAR, AMARILLO, LIMA, VIOLETA, MAGENTA, NEGRO, BLANCO, GRIS}COLORES;
typedef enum { BAI, EZ }ALGORITMOA_EGINDA;
typedef enum { CON_ESPACIO, SIN_ESPACIO }STOCK;
//produktu bakoitzaren kolorea eta stocka
typedef struct Stock_color {
	COLORES color;
	STOCK stockArriba;
	STOCK stockAbajo;
	struct Stock_color* ptrHurrengoa;
}STOCK_COLOR;
//produktu bakoitza
typedef struct Stock_produkto{

	ALMACENES producto;
	STOCK_COLOR* colores;
	struct Stock_produkto* ptrHurrengoa;

}STOCK_PRODUKTO;
//robotarentzako beharrezkoak diren informazio guztiak
typedef struct Robota{

	ALMACENES hasieraFuera;
	ALMACENES amaieraFuera;
	COLORES produktuarenKolorea;
	int hasieraBarruan;
	int puntuaBarruan;
	OBJ img;

}ROBOTA;
//mapen puntuen posizioa pantailan
typedef struct Almacenes{

	int punto;
	POSIZIOA pos;
	struct Almacenes* ptrHurrengoa;

}ALMACENES_POS;
//robotaren ibilbidea gordetzeko
typedef struct Caminos {

	int numero;
	struct Caminos* ptrHurrengoa;
}CAMINOS;
//mapen grafoetan errenkadak
typedef struct Mapa_fitx1 {

	int costea;
	struct Mapa_fitx1* ptrHurrengoaFila;

}MAPAK_FITX_FILAS;
//mapen grafoetan zutabeak
typedef struct Mapa_fitx2 {

	MAPAK_FITX_FILAS* filas;
	struct Mapa_fitx2* ptrHurrengoaColumna;

}MAPAK_FITX_COLUMNAS;
//mapa baten estructura bat,  id, tamaina, bi grafo, puntuak eta eginda dagoen
typedef struct Mapak {

	int id;
	int tamainaMapa;
	ALGORITMOA_EGINDA eginda;

	MAPAK_FITX_COLUMNAS* grafoDeCostos;
	MAPAK_FITX_COLUMNAS* grafoDeCaminos;
	ALMACENES_POS* puntos;

	struct Mapak* ptrHurrengoa;

}MAPAK;

typedef struct helbideak {
	int id;
	char imgMapa[MAX_STR];
	char imgRobot[MAX_STR];
	char imgDestino[MAX_STR];
	char txtMapa[MAX_STR];
	char txtPuntos[MAX_STR];
	struct helbideak* ptrHurrengoa;
}HELBIDEAK;


//Floyd Warshall sistemaren bitartez, bide motzenaren matrize itxurako zerrenda kateatu bat sortu, eta mapen struct-ean sartu
void floydWarshall(MAPAK* mapa, int ep);

//zein puntuetatik igaro behar duen arraya sortzen du, ordenean egongo dena
int caminoMasCorto(MAPAK mapa, CAMINOS** ibilbidea, ROBOTA robot);

//Lehenengo maparen Malloc-a sortzen du
void mapakHasieratu(MAPAK **mapas);

//Maparen pisuak fitxategitik hartzen ditu, eta emandako posizioan sartzen du
void mapakHasieratuFitx(MAPAK** ptrMapaLehena, char str[], int posizioa);

//Maparen pisuak filen zerrendaren amaieran sartzen ditu
void sartuAmaieran(MAPAK_FITX_FILAS** lehena, MAPAK_FITX_FILAS* aux);

//Maparen pisuak kolumnen zerrendaren amaieran sartzen ditu
void sartuAmaieranColumnas(MAPAK_FITX_COLUMNAS** lehena, MAPAK_FITX_COLUMNAS* aux);

//emandako mapa zerrendaren amaieran sartzen du
void sartuAmaieranMapa(MAPAK** lehena, MAPAK_FITX_COLUMNAS* aux, int tamaina);

//matrize baten itxura duen zerrenda kateatuan, i kolumnan eta j filan dagoen posizioan emandako zenbakia sartu
void mugituStructFitx(MAPAK_FITX_COLUMNAS** aux, int i, int j, int suma);

//matrize baten itxura duen zerrenda kateatuan, i kolumnan eta j filan dagoen posizioko balorea bueltatu
int bueltatuFilarenBalorea(MAPAK_FITX_COLUMNAS aux, int i, int j);


//zein puntuetatik igaro behar duen zerrenda kateatua sortzen du, ordenean egongo dena
CAMINOS* caminoMasCortoDijkstra(MAPAK_FITX_COLUMNAS* caminos, int inicio, int final);

//ikusita eta aurrekoa hasieratzeko erabiltzen dugu
void hasieratuDijkstra(MAPAK_FITX_FILAS** ikusita, MAPAK_FITX_FILAS** aurrekoa, int hasiera, int ep);


CAMINOS* dijkstra(MAPAK* mapa, int hasiera, int bukaera, int ep);

//A izarraren sistemaren bitartez, bide motzenaren zerrenda kateatua sortu, hau ordenean beste zerrendan sartu eta bueltatu
CAMINOS* A_estrella(MAPAK* mapa, int hasiera, int bukaera, int ep);

//mapen koordenatuak erabiliz, puntuen artean dagoen distantzia pixeletan neurtzen du
MAPAK_FITX_COLUMNAS* heuristika_kalkulatu(ALMACENES_POS* dist, int ep);

//x puntuaren koordenatuak bueltatzeko
POSIZIOA bueltatuPosizioa(ALMACENES_POS* aux, int i);

//mapa baten puntuen koordenatuak fitxategi batetik hartu eta mapa struct-aren barruan sartzen du
void puntuaHasieratu(ALMACENES_POS** puntos, char str[]);

//mapa baten puntuen koordenatuak fitxategi batean gordetzen ditu
void puntuaGorde(ALMACENES_POS* puntos, char str[]);

//Fitxategietatik Stockaren informazio guztia hartzen du, eta struct batean sartzen du
void stockHasieratu(STOCK_PRODUKTO** stockDeCadaProducto, char str[]);

//Stocka fitxategi batean gordetzeko funtzioa
void stockGorde(STOCK_PRODUKTO* stockDeCadaProducto, char str[]);



void grafoa_kalkulatu(MAPAK_FITX_COLUMNAS** mapa, ALMACENES_POS* dist, int ep);


void mapaGorde(MAPAK_FITX_COLUMNAS* mapa, char str[]);

#endif // !_OROKORRAK_H
