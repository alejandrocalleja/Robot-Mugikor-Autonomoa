#ifndef _OROKORRAK_H
#define _OROKORRAK_H

#define MAX_STR 128

typedef struct obj {
    int id;
    POSIZIOA pos;
}OBJ;

#endif // !_OROKORRAK_H

