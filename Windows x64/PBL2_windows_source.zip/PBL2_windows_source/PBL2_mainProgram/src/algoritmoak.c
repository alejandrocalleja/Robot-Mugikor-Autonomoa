#define _CRT_SECURE_NO_WARNINGS

#include <SDL.h>
#include <SDL_main.h>
#include <SDL_image.h>
#include <SDL_mixer.h>
#include <SDL_ttf.h>

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "events.h"
#include "orokorrak.h"
#include "defineak.h"

#include "algoritmoak.h"
#include "graphics.h"
#include "image.h"


#include "programa.h"
#include "algoritmoak.h"

//Floyd Warshall sistemaren bitartez, bide motzenaren matrize itxurako zerrenda kateatu bat sortu, eta mapen struct-ean sartu
void floydWarshall(MAPAK* mapa, int ep)
{
	int i, j, k, x1 = 0, x2 = 0, x3 = 0, x11;


	MAPAK_FITX_COLUMNAS *aux = NULL;
	aux = mapa->grafoDeCostos; //pisuen grafoa auxiliar batean sartu
	MAPAK_FITX_COLUMNAS* auxCaminos = NULL;


	MAPAK_FITX_COLUMNAS* grafoDeCaminosCOL = NULL, * aux1 = NULL;
	MAPAK_FITX_FILAS* grafoDeCaminosFIL = NULL, * aux2 = NULL;

	//matrize baten itxura izango duen zerrenda kateatuak sortu, kolumnaren arabera kolumnaren zenbakiarekin
	//ibilbideen matrize bat sortzen dugu
	for (i = 0; i < ep; i++) {
		grafoDeCaminosFIL = NULL;
		for (j = 0; j < ep; j++) {
			aux2 = (MAPAK_FITX_FILAS*)malloc(sizeof(MAPAK_FITX_FILAS));
			if (j == i) {
				aux2->costea = -1;
			}
			else {
				aux2->costea = j;
			}
			aux2->ptrHurrengoaFila = NULL;
			sartuAmaieran(&grafoDeCaminosFIL, aux2);
		}
		aux1 = (MAPAK_FITX_COLUMNAS*)malloc(sizeof(MAPAK_FITX_COLUMNAS));
		aux1->filas = grafoDeCaminosFIL;
		aux1->ptrHurrengoaColumna = NULL;
		sartuAmaieranColumnas(&grafoDeCaminosCOL, aux1);
	}
	//mapen struct-ean sartu
	mapa->grafoDeCaminos = grafoDeCaminosCOL;

	auxCaminos = mapa->grafoDeCaminos;


	for (k = 0; k < ep; k++) //Zutabe eta errenkadak mugitzeko
	{
		for (i = 0; i < ep; i++)//Errekanda mugitzeko
		{
			for (j = 0; j < ep; j++)//Zutabe mugitzeko
			{
				x11 = bueltatuFilarenBalorea(*auxCaminos, i, k);
				x1 = bueltatuFilarenBalorea(*aux, i, k);
				x2 = bueltatuFilarenBalorea(*aux, k, j);
				x3 = bueltatuFilarenBalorea(*aux, i, j);
				if (x1 + x2 < x3) {
					mugituStructFitx(&aux, i, j, x1 + x2);
					mugituStructFitx(&auxCaminos, i, j, x11);
				}
			}
		}
	}
	mapa->eginda = BAI;

}
//matrize baten itxura duen zerrenda kateatuan, i zutabean eta j errenkadean dagoen posizioan emandako zenbakia sartu
void mugituStructFitx(MAPAK_FITX_COLUMNAS** aux, int i, int j, int suma) {

	int x, k;
	MAPAK_FITX_COLUMNAS* aux2 = NULL;
	MAPAK_FITX_FILAS* auxFilas = NULL;


	aux2 = *aux;

	for (x = 0; x < i; x++) {
		aux2 = aux2->ptrHurrengoaColumna;
	}
	auxFilas = aux2->filas;

	for (k = 0; k < j; k++) {
		auxFilas = auxFilas->ptrHurrengoaFila;
	}
	auxFilas->costea = suma;

}
//matrize baten itxura duen zerrenda kateatuan, i zutabean eta j errenkadean dagoen posizioko balorea bueltatu
int bueltatuFilarenBalorea(MAPAK_FITX_COLUMNAS aux, int i, int j) {

	int x, k;

	MAPAK_FITX_COLUMNAS* aux2 = NULL;
	MAPAK_FITX_FILAS* auxFilas = NULL;

	aux2 = &aux;

	for (x = 0; x < i; x++) {//zutabetan aurrera egin
		aux2 = aux2->ptrHurrengoaColumna;
	}

	auxFilas = aux2->filas;

	for (k = 0; k < j; k++) {//errenkadetan aurrera egin
		auxFilas = auxFilas->ptrHurrengoaFila;
	}

	return auxFilas->costea;
}
//zein puntuetatik igaro behar duen zerrenda kateatua sortzen du, ordenean egongo dena
int caminoMasCorto(MAPAK mapa, CAMINOS** ibilbidea, ROBOTA robot) {

	int inicio;
	int final;
	int aurkitu = 0, costoIbil = 0;
	CAMINOS* ptrElementua = NULL;
	CAMINOS* aux = NULL;

	MAPAK_FITX_COLUMNAS* auxCOl = mapa.grafoDeCaminos;//ibilbide motzenaren zerrenda kateatuaren auxiliarra

	inicio = robot.hasieraFuera;
	final = robot.amaieraFuera;
	//hasierako malloc-a sortu
	*ibilbidea = (CAMINOS*)malloc(sizeof(CAMINOS));
	//amaierako puntua sartu
	(*ibilbidea)->numero = final;
	(*ibilbidea)->ptrHurrengoa = NULL;

	aux = *ibilbidea;
	while (aurkitu == 0) {//hasierako puntura heltzen den arte
		final = bueltatuFilarenBalorea(*auxCOl, final, inicio);//puntu batera ailegatzeko behar den aurreko puntua hartu, ibilbideen matrizetik
		//zerrendaren lehenengo posizioan hartutako zenbakia sartu
		if (inicio != -1) {
			ptrElementua = (CAMINOS*)malloc(sizeof(CAMINOS));
			ptrElementua->numero = final;

			ptrElementua->ptrHurrengoa = *ibilbidea;
			*ibilbidea = ptrElementua;
		}
		else {
			aurkitu = 1;
		}

		if (inicio == final) {
			aurkitu = 1;
		}
	}

	return costoIbil;
}
//Lehenengo maparen Malloc-a sortzen du
void mapakHasieratu(MAPAK** ptrMapaLehena) {

	*ptrMapaLehena = (MAPAK*)malloc(sizeof(MAPAK));
	if (*ptrMapaLehena != 0) {
		(*ptrMapaLehena)->id = 1;
		(*ptrMapaLehena)->eginda = EZ;
		(*ptrMapaLehena)->grafoDeCostos = NULL;
		(*ptrMapaLehena)->ptrHurrengoa = NULL;

	}
	
}

//Maparen pisuak fitxategitik hartzen ditu, eta emandako posizioan sartzen du
void mapakHasieratuFitx(MAPAK** ptrMapaLehena, char str[], int posizioa) {
	int egoera = 0, j = 0, i = 0, id = 1;
	MAPAK *auxMapa;
	MAPAK_FITX_COLUMNAS* mapa = NULL, * aux = NULL;
	MAPAK_FITX_FILAS* mapa2 = NULL, * aux2 = NULL;
	FILE* fitx_erakuslea;
	char l;
	fitx_erakuslea = fopen(str,
		"r");

	if (fitx_erakuslea > 0) {
		do {
			mapa2 = NULL;
			do {
				//Maparen filak auxiliar baten barruan sartzen ditu
				aux2 = (MAPAK_FITX_FILAS*)malloc(sizeof(MAPAK_FITX_FILAS));
				egoera = fscanf(fitx_erakuslea, "%i, ", &(aux2->costea));
				aux2->ptrHurrengoaFila = NULL;
				if (egoera > 0) {
					sartuAmaieran(&mapa2, aux2);
				}
				else { //Ezer hartzen ez duenean, azkeneko introa hartzen du, eta salto egiten du
					l = fgetc(fitx_erakuslea);
					if (l == '\n') {
						egoera = 0;
					}
				}
			} while (egoera > 0);
			//Maparen kolumnak sortu, eta filak barruan sartzen ditu
			aux = (MAPAK_FITX_COLUMNAS*)malloc(sizeof(MAPAK_FITX_COLUMNAS));
			aux->filas = mapa2;
			aux->ptrHurrengoaColumna = NULL;
			sartuAmaieranColumnas(&mapa, aux);
			j++;
		} while (egoera != EOF);
		//pisuen mapa, maparen struct nagusian sartzeko, zerrenda nagusiaren emandako posizioan sartzen da
		auxMapa = (*ptrMapaLehena);

		if (posizioa == 0) {//lehen posizioa bada, hasieran sartu
			sartuAmaieranMapa(&auxMapa, mapa, j);
		}
		else {//beste posizio bat bada, posizio horren auxiliarrean pisuaren mapa sartu
			for (i = 1; i < posizioa; i++) {
				auxMapa = auxMapa->ptrHurrengoa;
			}
			auxMapa->eginda = EZ;
			auxMapa->grafoDeCostos = mapa;
			auxMapa->grafoDeCaminos = NULL;
		}
		fclose(fitx_erakuslea);
	}
	else {
		printf("ERROR: Arazoak %s fitxategia zabaltzerakoan.\n", str);
	}
}
//Maparen pisuak filen zerrendaren amaieran sartzen ditu
void sartuAmaieran(MAPAK_FITX_FILAS** lehena, MAPAK_FITX_FILAS* aux) {

	MAPAK_FITX_FILAS* aux2 = NULL;

	aux2 = *lehena;

	if (*lehena == NULL) {//lehena NULL bada, malloc bat egiten dugu eta malloc horretan auxiliarra sartzen dugu
		*lehena = (MAPAK_FITX_FILAS*)malloc(sizeof(MAPAK_FITX_FILAS));
		*lehena = aux;
	}
	else {
		while (aux2->ptrHurrengoaFila != NULL) {
			aux2 = aux2->ptrHurrengoaFila;
		}
		aux2->ptrHurrengoaFila = aux;
	}
}
//Maparen pisuak kolumnen zerrendaren amaieran sartzen ditu
void sartuAmaieranColumnas(MAPAK_FITX_COLUMNAS** lehena, MAPAK_FITX_COLUMNAS* aux) {

	MAPAK_FITX_COLUMNAS* aux2 = NULL;

	aux2 = *lehena;

	if (*lehena == NULL) {
		*lehena = (MAPAK_FITX_COLUMNAS*)malloc(sizeof(MAPAK_FITX_COLUMNAS));
		*lehena = aux;
	}
	else {
		while (aux2->ptrHurrengoaColumna != NULL) {
			aux2 = aux2->ptrHurrengoaColumna;
		}
		aux2->ptrHurrengoaColumna = aux;
	}
}
//emandako mapa zerrendaren amaieran sartzen du
void sartuAmaieranMapa(MAPAK** lehena, MAPAK_FITX_COLUMNAS* aux, int tamaina) {
	int id = 1;
	MAPAK *auxMapa2;


	if ((*lehena)->grafoDeCostos == NULL) {
		(*lehena)->id = 1;
		(*lehena)->grafoDeCostos = aux;
		(*lehena)->tamainaMapa = tamaina - 1;
	}
	else {
		id++;
		while ((*lehena)->ptrHurrengoa != NULL) {
			id++;
			(*lehena) = (*lehena)->ptrHurrengoa;
		}
		auxMapa2 = (MAPAK*)malloc(sizeof(MAPAK));

		auxMapa2->eginda = EZ;
		auxMapa2->ptrHurrengoa = NULL;
		auxMapa2->id = id;
		auxMapa2->grafoDeCostos = aux;
		auxMapa2->tamainaMapa = tamaina - 1;
		auxMapa2->grafoDeCaminos = NULL;

		(*lehena)->ptrHurrengoa = auxMapa2;
	}
}

//zein puntuetatik igaro behar duen zerrenda kateatua sortzen du, ordenean egongo dena
CAMINOS* caminoMasCortoDijkstra(MAPAK_FITX_COLUMNAS* caminos, int inicio, int final) {

	int x = inicio, aurkitu = 0;
	CAMINOS* ptrElementua = NULL;
	CAMINOS* aux = NULL;

	aux = (CAMINOS*)malloc(sizeof(CAMINOS));

	aux->numero = final;
	aux->ptrHurrengoa = NULL;

	while (aurkitu == 0) {//hasierako puntura ailegatzen den arte
		final = bueltatuFilarenBalorea(*caminos, 0, final - 1);//puntu batera ailegatzeko behar den aurreko puntua hartu, ibilbideen zerrendatik
		//zerrendaren lehenengo posizioan hartutako zenbakia sartu
		if (final != 0) {

			ptrElementua = (CAMINOS*)malloc(sizeof(CAMINOS));

			ptrElementua->numero = final;
			ptrElementua->ptrHurrengoa = aux;

			aux = ptrElementua;
		}
		else {
			aurkitu = 1;
		}

		if (inicio == final) {
			aurkitu = 1;
		}
	}


	return aux;
}
//ikusita eta aurrekoa hasieratzeko erabiltzen dugu
void hasieratuDijkstra(MAPAK_FITX_FILAS **ikusita, MAPAK_FITX_FILAS **aurrekoa, int hasiera, int ep) {
	int i;
	MAPAK_FITX_FILAS* aux;

	(*ikusita) = NULL;
	(*aurrekoa) = NULL;

	for (i = 0; i < ep; i++) {
		aux = (MAPAK_FITX_FILAS*)malloc(sizeof(MAPAK_FITX_FILAS));
		aux->ptrHurrengoaFila = NULL;
		if (i == hasiera) aux->costea = 1;
		else aux->costea = 0;
		sartuAmaieran(ikusita, aux);
	}

	for (i = 0; i < ep; i++) {
		aux = (MAPAK_FITX_FILAS*)malloc(sizeof(MAPAK_FITX_FILAS));
		aux->ptrHurrengoaFila = NULL;
		if(i == hasiera) aux->costea = hasiera;
		else aux->costea = -1;
		sartuAmaieran(aurrekoa, aux);
	}
}
CAMINOS* dijkstra(MAPAK* mapa, int hasiera, int bukaera, int ep) {

	MAPAK_FITX_COLUMNAS *ikusita, *aurrekoa;
	ikusita = (MAPAK_FITX_COLUMNAS*)malloc(sizeof(MAPAK_FITX_COLUMNAS));
	aurrekoa = (MAPAK_FITX_COLUMNAS*)malloc(sizeof(MAPAK_FITX_COLUMNAS));


	int x1 = 0, x2 = 0, x3 = 0, kont = 0;
	int i = 0, tmp = INF, pos = hasiera;
	int bukatu = 0, n;

	MAPAK_FITX_COLUMNAS* aux = NULL;
	aux = mapa->grafoDeCostos;
	CAMINOS* ptrLehena;

	hasieratuDijkstra(&ikusita->filas, &aurrekoa->filas, hasiera, ep);

	while (i < ep && bukatu == 0) {

		for (n = 0; n < ep; n++) {
			x1 = bueltatuFilarenBalorea(*aux, hasiera, n);
			x2 = bueltatuFilarenBalorea(*aux, pos, n);
			x3 = bueltatuFilarenBalorea(*aux, hasiera, pos);

			if (x1 > x2 + x3 && x2 + x3 < INF) {
				mugituStructFitx(&aux, hasiera, n, x2 + x3);
				mugituStructFitx(&aurrekoa, 0, n, pos + 1);
			}
		}

		mugituStructFitx(&ikusita, 0, pos, 1);

		for (n = 0; n < ep; n++) {
			x1 = bueltatuFilarenBalorea(*aux, hasiera, n);

			if (tmp > x1 && bueltatuFilarenBalorea(*ikusita, 0, n) == 0) {
				tmp = x1;
				pos = n;
			}
		}

		if (bueltatuFilarenBalorea(*aurrekoa, 0, pos) == -1) {
			mugituStructFitx(&aurrekoa, 0, pos, hasiera + 1);
		}
		if (pos == bukaera) bukatu = 1;

		tmp = INF;
		i++;
	}

	ptrLehena = caminoMasCortoDijkstra(aurrekoa, hasiera + 1, bukaera + 1);

	return ptrLehena;

}

//A izarraren sistemaren bitartez, bide motzenaren zerrenda kateatua sortu, hau ordenean beste zerrendan sartu eta bueltatu
CAMINOS* A_estrella(MAPAK* mapa, int hasiera, int bukaera, int ep) {

	MAPAK_FITX_COLUMNAS* ikusita, * aurrekoa;//ikusita puntu batetik kalkuluak egin ditugun ikusiko du, eta aurrekoa puntu batera ailegatzeko zein den aurreko puntua
	ikusita = (MAPAK_FITX_COLUMNAS*)malloc(sizeof(MAPAK_FITX_COLUMNAS));
	aurrekoa = (MAPAK_FITX_COLUMNAS*)malloc(sizeof(MAPAK_FITX_COLUMNAS));


	int x1 = 0, x2 = 0, x3 = 0, kont = 0;
	int z1, z2, z3, tot1, tot2, tot3;
	int i = 0, tmp = INF, pos = hasiera;
	int bukatu = 0, n;

	MAPAK_FITX_COLUMNAS* aux = NULL, *auxdist = NULL;
	aux = mapa->grafoDeCostos;


	auxdist = mapa->grafoDeCaminos;
	CAMINOS* ptrLehena;

	hasieratuDijkstra(&ikusita->filas, &aurrekoa->filas, hasiera, ep);

	while (i < ep && bukatu == 0) {//puntua aurkitu arte

		for (n = 0; n < ep; n++) {
			x1 = bueltatuFilarenBalorea(*aux, hasiera, n);
			x2 = bueltatuFilarenBalorea(*aux, pos, n);
			x3 = bueltatuFilarenBalorea(*aux, hasiera, pos);

			z1 = bueltatuFilarenBalorea(*auxdist, hasiera, n);
			z2 = bueltatuFilarenBalorea(*auxdist, pos, n);
			z3 = bueltatuFilarenBalorea(*auxdist, hasiera, pos);

			tot1 = x1 + z1;
			tot2 = x2 + z2;
			tot3 = x3 + z3;

			if (tot1 > tot2 + tot3 && x2 + x3 < INF) { // puntu batera bide motzago bat aurkitu badugu, bide hori sartu
				mugituStructFitx(&aux, hasiera, n, x2 + x3); 
				mugituStructFitx(&aurrekoa, 0, n, pos + 1); //bakarrik puntu batetik kalkulua egingo dugunez, matrizearen 0-garren kolumnan sartuko dugu dena
			}
		}

		mugituStructFitx(&ikusita, 0, pos, 1); //aurreko zenbakia ikusita egongo da

		for (n = 0; n < ep; n++) {
			x1 = bueltatuFilarenBalorea(*aux, hasiera, n);
			z1 = bueltatuFilarenBalorea(*auxdist, hasiera, n);

			tot1 = x1 + z1;

			if (tmp > tot1 && bueltatuFilarenBalorea(*ikusita, 0, n) == 0) { // pisu txikiena izango duen zenbakia hartu
				tmp = tot1;
				pos = n;
			}
		}

		if (bueltatuFilarenBalorea(*aurrekoa, 0, pos) == -1) { //lehenengo bueltan, hasierako zenbakiaren aurrekoa hasiera izango da
			mugituStructFitx(&aurrekoa, 0, pos, hasiera + 1);
		}
		if (pos == bukaera) bukatu = 1;

		tmp = INF;
		i++;
	}

	ptrLehena = caminoMasCortoDijkstra(aurrekoa, hasiera + 1, bukaera + 1);

	return ptrLehena;

}
//mapen koordenatuak erabiliz, puntuen artean dagoen distantzia pixeletan neurtzen du
MAPAK_FITX_COLUMNAS* heuristika_kalkulatu(ALMACENES_POS* dist, int ep) {

	MAPAK_FITX_COLUMNAS* aux = (MAPAK_FITX_COLUMNAS*)malloc(sizeof(MAPAK_FITX_COLUMNAS));
	POSIZIOA pos;
	double xhasiera, yhasiera, x1, y1, xtot, ytot;
	//int xtot, ytot;


	MAPAK_FITX_COLUMNAS* grafoDeCaminosCOL = NULL, * aux1 = NULL;
	MAPAK_FITX_FILAS* grafoDeCaminosFIL = NULL, * aux2 = NULL;
	//matrize itxurako zerrenda kateatua hasieratzen du
	for (int i = 0; i < ep; i++) {
		grafoDeCaminosFIL = NULL;
		for (int j = 0; j < ep; j++) {
			aux2 = (MAPAK_FITX_FILAS*)malloc(sizeof(MAPAK_FITX_FILAS));
			aux2->costea = 0;
			aux2->ptrHurrengoaFila = NULL;
			sartuAmaieran(&grafoDeCaminosFIL, aux2);
		}
		aux1 = (MAPAK_FITX_COLUMNAS*)malloc(sizeof(MAPAK_FITX_COLUMNAS));
		aux1->filas = grafoDeCaminosFIL;
		aux1->ptrHurrengoaColumna = NULL;
		sartuAmaieranColumnas(&grafoDeCaminosCOL, aux1);
	}
	//zerrenda kateatu hori auxiliar batean sartzen du
	aux = grafoDeCaminosCOL;

	//puntu guztien artean distantia kalkulatu
	for (int i = 0; i < ep; i++) {
		pos = bueltatuPosizioa(dist, i);
		xhasiera = pos.x;
		yhasiera = pos.y;

		for (int j = 0; j < ep; j++) {
			pos = bueltatuPosizioa(dist, j);

			x1 = pos.x;
			y1 = pos.y;

			xtot = fabs(xhasiera - x1);
			ytot = fabs(yhasiera - y1);

			mugituStructFitx(&aux, i, j, (int)xtot + (int)ytot); //auxiliarraren barruan sartu
		}
	}

	return aux;
}
//x puntuaren koordenatuak bueltatzeko
POSIZIOA bueltatuPosizioa(ALMACENES_POS* aux, int i) {

	ALMACENES_POS* aux2 = NULL;
	POSIZIOA auxpos;
	aux2 = aux;

	for (int x = 0; x < i; x++) {
		aux2 = aux2->ptrHurrengoa;
	}
	auxpos = aux2->pos;

	return auxpos;
}

//CAMINOS* dijkstra(MAPAK* mapa, int hasiera, int bukaera, int* kostua) {
//	int ikusita[EP2], aurrekoa[EP2];
//
//	CAMINOS* ptrLehena;
//	int i = 0, tmp = INF, pos = hasiera;
//	int x = hasiera;
//	int bukatu = 0, n;
//
//
//	hasieratuDijkstra(ikusita, aurrekoa, hasiera);
//
//
//	while (i < EP2 && bukatu == 0) {
//
//
//		for (n = 0; n < EP2; n++) {
//			if (mapa->grafoDeCostos2[hasiera][n] > mapa->grafoDeCostos2[pos][n] + mapa->grafoDeCostos2[hasiera][pos] && mapa->grafoDeCostos2[pos][n] + mapa->grafoDeCostos2[hasiera][pos] < INF) {
//				mapa->grafoDeCostos2[hasiera][n] = mapa->grafoDeCostos2[pos][n] + mapa->grafoDeCostos2[hasiera][pos];
//				aurrekoa[n] = pos + 1;
//			}
//		}
//
//		for (n = 0; n < EP2; n++) {
//			if (tmp > mapa->grafoDeCostos2[hasiera][n] && ikusita[n] == 0) {
//				tmp = mapa->grafoDeCostos2[hasiera][n];
//				pos = n;
//			}
//		}
//		if (aurrekoa[pos] == -1) {
//			aurrekoa[pos] = hasiera + 1;
//		}
//
//
//		if (pos == bukaera) bukatu = 1;
//
//
//		ikusita[pos] = 1;
//		tmp = INF;
//		i++;
//	}
//	//*kostua = grafoa[hasiera][bukaera];
//
//	ptrLehena = caminoMasCortoDijkstra(aurrekoa, hasiera + 1, bukaera + 1);
//
//	return ptrLehena;
//
//}

//mapa baten puntuen koordenatuak fitxategi batetik hartu eta mapa struct-aren barruan sartzen du
void puntuaHasieratu(ALMACENES_POS** puntos, char str[]) {
	int egoera;
	FILE* fitx_erakuslea;
	ALMACENES_POS* aux = NULL, * aux2;

	fitx_erakuslea = fopen(str,
		"r");

	if (fitx_erakuslea > 0) {
		//hasieratzeko malloc-a sortu
		(*puntos) = (ALMACENES_POS*)malloc(sizeof(ALMACENES_POS));
		(*puntos) = NULL;

		do {
			//puntuak hartzen dituen bitartean, puntuen zerrenda kateatuaren amaieran sartu
			aux = (ALMACENES_POS*)malloc(sizeof(ALMACENES_POS));
			egoera = fscanf(fitx_erakuslea, "%d, %d %d\n", &aux->punto, &aux->pos.x, &aux->pos.y);
			aux2 = (*puntos);

			if (egoera > 0) {
				if (*puntos == NULL) {
					*puntos = aux;
					aux->ptrHurrengoa = NULL;
				}
				else {
					while (aux2->ptrHurrengoa != NULL) {
						aux2 = aux2->ptrHurrengoa;
					}
					aux2->ptrHurrengoa = aux;
					aux->ptrHurrengoa = NULL;
				}
			}

		} while (egoera > 0);

		fclose(fitx_erakuslea);
	}
	else {
		printf("Errorea %s fitxategia sortzerakoan.\n",
			str);
	}

}
//mapa baten puntuen koordenatuak fitxategi batean gordetzen ditu
void puntuaGorde(ALMACENES_POS* puntos, char str[]) {
	FILE* fitx_erakuslea;

	fitx_erakuslea = fopen(str,
		"w");


	if (fitx_erakuslea > 0) {
		while (puntos != NULL) {
			fprintf(fitx_erakuslea, "%d, %d %d\n", puntos->punto, puntos->pos.x, puntos->pos.y);

			puntos = puntos->ptrHurrengoa;
		}

		fclose(fitx_erakuslea);
	}
	else {
		printf("Errorea %s fitxategia sortzerakoan.\n",
			str);
	}

}
//Fitxategietatik Stockaren informazio guztia hartzen du, eta struct batean sartzen du
void stockHasieratu(STOCK_PRODUKTO** stockDeCadaProducto, char str[]) {
	int egoera, l;
	FILE* fitx_erakuslea;
	STOCK_PRODUKTO* aux = NULL, * aux2;
	STOCK_COLOR* auxColor = NULL;
	STOCK_COLOR* auxColor2 = NULL;

	
	fitx_erakuslea = fopen(str,
		"r");

	if (fitx_erakuslea > 0) {
		//Lehenengo malloc-a sortu
		*stockDeCadaProducto = (STOCK_PRODUKTO*)malloc(sizeof(STOCK_PRODUKTO));
		*stockDeCadaProducto = NULL;


		do {
			//Produktuak hartzen ditu, eta amaieran sartzen ditu
			aux = (STOCK_PRODUKTO*)malloc(sizeof(STOCK_PRODUKTO));
			egoera = fscanf(fitx_erakuslea, "%d: \n\n", &aux->producto);
			aux2 = *stockDeCadaProducto;

			if (egoera > 0) {
				if (*stockDeCadaProducto == NULL) {
					*stockDeCadaProducto = aux;
					aux->ptrHurrengoa = NULL;
					aux->colores = NULL;
				}
				else {
					while (aux2->ptrHurrengoa != NULL) {
						aux2 = aux2->ptrHurrengoa;
					}
					aux2->ptrHurrengoa = aux;
					aux->ptrHurrengoa = NULL;
					aux->colores = NULL;
				}

				do {
					//Produktuen Koloreak eta beteta dauden hartzen ditu, eta produktuen barruan, amaieran sartzen ditu
					auxColor = (STOCK_COLOR*)malloc(sizeof(STOCK_COLOR));
					l = fscanf(fitx_erakuslea, "%d, %d %d\n", &auxColor->color, &auxColor->stockAbajo, &auxColor->stockArriba);
					auxColor2 = aux->colores;

					if (aux->colores == NULL) {
						aux->colores = auxColor;
						auxColor->ptrHurrengoa = NULL;
					}
					else {
						while (auxColor2->ptrHurrengoa != NULL) {
							auxColor2 = auxColor2->ptrHurrengoa;
						}
						auxColor2->ptrHurrengoa = auxColor;
						auxColor->ptrHurrengoa = NULL;
					}

				} while (auxColor->color != 0);
			}

		} while (egoera > 0);

		fclose(fitx_erakuslea);
	}
	else {
		printf("Errorea %s fitxategia sortzerakoan.\n",
			str);
	}
}
//Stocka fitxategi batean gordetzeko funtzioa
void stockGorde(STOCK_PRODUKTO* stockDeCadaProducto, char str[]) {
	FILE* fitx_erakuslea;

	fitx_erakuslea = fopen(str,
		"w");

	if (fitx_erakuslea > 0) {

		while (stockDeCadaProducto != NULL) {
			fprintf(fitx_erakuslea, "%d: \n\n", stockDeCadaProducto->producto);

			while (stockDeCadaProducto->colores != NULL) {
				fprintf(fitx_erakuslea, "%d, %d %d\n", stockDeCadaProducto->colores->color, stockDeCadaProducto->colores->stockAbajo, stockDeCadaProducto->colores->stockArriba);

				stockDeCadaProducto->colores = stockDeCadaProducto->colores->ptrHurrengoa;
			}

			stockDeCadaProducto = stockDeCadaProducto->ptrHurrengoa;

		}

		fclose(fitx_erakuslea);
	}
	else {
		printf("Errorea %s fitxategia sortzerakoan.\n",
			str);
	}
}


void grafoa_kalkulatu(MAPAK_FITX_COLUMNAS** mapa, ALMACENES_POS* dist, int ep) {

	MAPAK_FITX_COLUMNAS* aux;

	POSIZIOA pos;
	double xhasiera, yhasiera, x1, y1, xtot, ytot;;
	//int x1, y1, xtot, ytot;
	int max = ep - 1;
	aux = *mapa;

	for (int i = 0; i < ep; i++) {
		pos = bueltatuPosizioa(dist, max - i);
		xhasiera = pos.x;
		yhasiera = pos.y;

		for (int j = 0; j < ep; j++) {
			pos = bueltatuPosizioa(dist, max - j);

			x1 = pos.x;
			y1 = pos.y;

			xtot = fabs(xhasiera - x1);
			ytot = fabs(yhasiera - y1);

			if (bueltatuFilarenBalorea(*aux, i, j) == 0) {
				mugituStructFitx(&aux, i, j, INF);
			}
			else {
				mugituStructFitx(&aux, i, j, (int)xtot + (int)ytot);
			}	
		}
	}

}
//mapen struct-ak fitxategi batean gordetzen ditugu
void mapaGorde(MAPAK_FITX_COLUMNAS* mapa, char str[]) {
	FILE* fitx_erakuslea;

	fitx_erakuslea = fopen(str,
		"w");


	if (fitx_erakuslea > 0) {
		do {
			do {
				fprintf(fitx_erakuslea, "%d", mapa->filas->costea);

				if (mapa->filas->ptrHurrengoaFila != NULL) {
					fprintf(fitx_erakuslea, ", ");
				}
				else {
					fprintf(fitx_erakuslea, "/\n");
				}
				mapa->filas = mapa->filas->ptrHurrengoaFila;

			} while (mapa->filas != NULL);

			mapa = mapa->ptrHurrengoaColumna;

		} while (mapa != NULL);

		fclose(fitx_erakuslea);
	}
	else {
		printf("Errorea %s fitxategia sartzerakoan.\n",
			str);
	}

}