#ifndef _GRAPHICS_H
#define _GRAPHICS_H

SDL_Renderer* getRenderer(void);

//Pantailaren tamaina hartzen du eta lehioa sortzen du
int programaHasieratu(void);
SDL_DisplayMode pantailarenTamainaAtera();
int imgMarraztu(SDL_Texture* texture, SDL_Rect* pDest);
//Sortutako lehioa ixten du
void lehioaItxi(void);
int programaHasieratu(void);
void programaAmaitu();
#endif // !_GRAPHICS_H

