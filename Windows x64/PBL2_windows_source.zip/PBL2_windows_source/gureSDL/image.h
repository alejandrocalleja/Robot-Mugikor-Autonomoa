#ifndef _IMAGE_H
#define _IMAGE_H

#define MAX_IMG 100

typedef struct img {
    int id;
    SDL_Texture* texture;
    SDL_Rect dest;
    struct img* pNext;
}IMG, *pIMG;

int imgKargatu(char* fileName);
int imgMugitu(int id, int x, int y);
void imgsMarraztu(void);
pIMG imgBilatu(int id);
void imgListarenBukaeranSartu(pIMG* pHead, pIMG src);
void imgKendu(int id);

#endif // !_IMAGE_H

